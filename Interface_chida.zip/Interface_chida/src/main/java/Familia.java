public class Familia extends Evento {
    public Familia(String nombre, int duracionHoras) {
        super(nombre, duracionHoras);
    }

    @Override
    public String obtenerCategoria() {
        return "Familia";
    }
}
