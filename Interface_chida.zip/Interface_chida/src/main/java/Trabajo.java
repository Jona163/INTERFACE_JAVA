 public class Trabajo extends Evento {
    public Trabajo(String nombre, int duracionHoras) {
        super(nombre, duracionHoras);
    }

    @Override
    public String obtenerCategoria() {
        return "Trabajo";
    }
}

    
    

