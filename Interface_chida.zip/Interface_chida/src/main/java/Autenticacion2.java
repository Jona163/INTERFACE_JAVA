import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Autenticacion2 extends JFrame {
    private JTextField campoUsername;
    private JPasswordField campoPassword;
    private JButton loginButton;
    private JButton cancelButton;
    private int intentos = 0;
    private final int MAX_INTENTOS = 3;

    public Autenticacion2() {
        setTitle("Inicio de Sesión");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla

        // Configurar el panel principal
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setBackground(Color.WHITE);

        // Panel para el formulario
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        formPanel.setBackground(Color.WHITE);

        // Campos de texto y etiquetas
        JLabel usernameLabel = new JLabel("Usuario:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        campoUsername = new JTextField(15);
        JLabel passwordLabel = new JLabel("Contraseña:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        campoPassword = new JPasswordField(15);

        // Agregar componentes al panel de formulario
        formPanel.add(usernameLabel);
        formPanel.add(campoUsername);
        formPanel.add(passwordLabel);
        formPanel.add(campoPassword);

        // Panel para los botones
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(Color.WHITE);

        loginButton = new JButton("Iniciar Sesión");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validarLogin();
            }
        });
        cancelButton = new JButton("Cancelar");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Agregar botones al panel de botones
        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);

        // Agregar paneles al panel principal
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void validarLogin() {
        String username = campoUsername.getText();
        String password = new String(campoPassword.getPassword());
        try {
            if (validUsernamePassword(username, password)) {
                JOptionPane.showMessageDialog(this, "¡Bienvenid@, " + username + "!", "Inicio de Sesión Exitoso", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Cerrar la ventana de inicio de sesión
                abrirGestorHorarios(); // Abrir la ventana del gestor de horarios
            } else {
                intentos++;
                if (intentos >= MAX_INTENTOS) {  JOptionPane.showMessageDialog(this, "Nombre de usuario o contraseña incorrectos. Intentos restantes: " + (MAX_INTENTOS - intentos), "Inicio de Sesión Fallido", JOptionPane.WARNING_MESSAGE);
                }
            }
        } catch (NullPointerException e) {
            // TODO: handle exception
            JOptionPane.showMessageDialog(this, "Nombre de usuario o contraseña incorrectos. Intentos restantes: " + (MAX_INTENTOS - intentos), "Inicio de Sesión Fallido", JOptionPane.WARNING_MESSAGE);
        }
    }

    private boolean validUsernamePassword(String username, String password) {
        // Verificar si el nombre de usuario y contraseña son correctos
        return username.equals("Jessica") && password.equals("Morales");
    }

    private void abrirGestorHorarios() {
        GestorHorarios ventanaGestor = new GestorHorarios();
        ventanaGestor.setVisible(true);
    }

    public static void main(String[] args) {
        // Crear una instancia de la clase Autenticacion2 y hacerla visible
        Autenticacion2 ventanaLogin = new Autenticacion2();
        ventanaLogin.setVisible(true);
    }
}
