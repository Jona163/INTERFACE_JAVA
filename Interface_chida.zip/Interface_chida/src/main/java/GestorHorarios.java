import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class GestorHorarios extends JFrame {
    private Map<String, List<String>> horariosActividades;
    private JList<String> horariosList;
    private DefaultListModel<String> horariosListModel;
    private JTextField actividadField;
    private JComboBox<String> diasCombo;

    public GestorHorarios() {
        setTitle("Gestor de Horarios");
        setSize(400, 350);
        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Configurar la interfaz de la ventana
        JPanel panelPrincipal = new JPanel(new BorderLayout());

        // Panel para agregar horarios y actividades
        JPanel panelAgregar = new JPanel(new GridLayout(2, 2, 5, 5));
        panelAgregar.setBorder(BorderFactory.createTitledBorder("Agregar Horario"));
        JLabel actividadLabel = new JLabel("Actividad:");
        actividadField = new JTextField(15);
        JLabel diaLabel = new JLabel("Día:");
        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        diasCombo = new JComboBox<>(dias);
        JButton agregarButton = new JButton("Agregar");
        agregarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    agregarHorario();
                } catch (CampoVacioException ex) {
                    JOptionPane.showMessageDialog(GestorHorarios.this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        panelAgregar.add(actividadLabel);
        panelAgregar.add(actividadField);
        panelAgregar.add(diaLabel);
        panelAgregar.add(diasCombo);
        panelAgregar.add(agregarButton);

        // Panel para eliminar horarios y actividades
        JPanel panelEliminar = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelEliminar.setBorder(BorderFactory.createTitledBorder("Eliminar Horario"));
        final JButton eliminarButton = new JButton("Eliminar");
        eliminarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarHorario();
            }
        });
        panelEliminar.add(eliminarButton);

        // Panel para mostrar los horarios y actividades
        JPanel panelHorarios = new JPanel(new BorderLayout());
        panelHorarios.setBorder(BorderFactory.createTitledBorder("Horarios y Actividades"));
        horariosListModel = new DefaultListModel<>();
        horariosList = new JList<>(horariosListModel);
        JScrollPane scrollPane = new JScrollPane(horariosList);
        panelHorarios.add(scrollPane, BorderLayout.CENTER);

        // Agregar paneles a la ventana principal
        panelPrincipal.add(panelAgregar, BorderLayout.NORTH);
        panelPrincipal.add(panelEliminar, BorderLayout.CENTER);
        panelPrincipal.add(panelHorarios, BorderLayout.SOUTH);

        getContentPane().add(panelPrincipal);

        // Inicializar mapa de horarios y actividades
        horariosActividades = new HashMap<>();
        inicializarDatos();

        // Cargar los horarios y actividades al iniciar la aplicación
        cargarHorariosActividades();
        actualizarListaHorarios();

        // Escuchar cambios en la selección del combo de días
        diasCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizarListaHorarios();
            }
        });

        // Escuchar cambios en la selección de la lista de actividades
        horariosList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    eliminarButton.setEnabled(horariosList.getSelectedIndex() != -1);
                }
            }
        });
    }

    private void inicializarDatos() {
        // Inicializar los días de la semana en el mapa
        String[] diasSemana = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        for (String dia : diasSemana) {
            horariosActividades.put(dia, new ArrayList<String>());
        }
    }

    // Creamos la excepción
    public class CampoVacioException extends Exception {
        public CampoVacioException(String mensaje) {
            super(mensaje);
        }
    }

    private void agregarHorario() throws CampoVacioException {
        String actividad = actividadField.getText().trim();
        String diaSeleccionado = (String) diasCombo.getSelectedItem();
        if (actividad.isEmpty()) {
            throw new CampoVacioException("El campo de actividad no puede estar vacío.");
        }
        try {
            List<String> actividadesDia = horariosActividades.get(diaSeleccionado);
            actividadesDia.add(actividad);
            actualizarListaHorarios();
            guardarHorariosActividades();
            actividadField.setText(""); // Limpiar campo de texto después de agregar
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa una actividad.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarHorario() {
        String seleccion = horariosList.getSelectedValue();
        try {
            if (seleccion != null) {
                String diaSeleccionado = (String) diasCombo.getSelectedItem();
                List<String> actividadesDia = horariosActividades.get(diaSeleccionado);
                actividadesDia.remove(seleccion.substring(diaSeleccionado.length() + 2)); // Eliminar la actividad seleccionada
                actualizarListaHorarios();
                guardarHorariosActividades();
            } else {
                JOptionPane.showMessageDialog(this, "Por favor selecciona una actividad para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NullPointerException e) {
            JOptionPane.showMessageDialog(this, "Por favor selecciona una actividad para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarListaHorarios() {
        horariosListModel.clear();
        String diaSeleccionado = (String) diasCombo.getSelectedItem();
        List<String> actividadesDia = horariosActividades.get(diaSeleccionado);
        for (String actividad : actividadesDia) {
            horariosListModel.addElement(diaSeleccionado + ": " + actividad);
        }
    }

    private void cargarHorariosActividades() {
        try {
            Scanner scanner = new Scanner(new File("horarios_actividades.txt"));
            while (scanner.hasNextLine()) {
                String[] partes = scanner.nextLine().split(":");
                String dia = partes[0];
                String actividad = partes[1];
                List<String> actividadesDia = horariosActividades.get(dia);
                actividadesDia.add(actividad);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            // El archivo no existe, se creará uno nuevo al guardar horarios y actividades
        }
    }

    private void guardarHorariosActividades() {
        try {
            PrintWriter writer = new PrintWriter(new File("horarios_actividades.txt"));
            for (Map.Entry<String, List<String>> entrada : horariosActividades.entrySet()) {
                String dia = entrada.getKey();
                List<String> actividadesDia = entrada.getValue();
                for (String actividad : actividadesDia) {
                    writer.println(dia + ":" + actividad);
                }
            }
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new GestorHorarios().setVisible(true);
            }
        });
    }
}
