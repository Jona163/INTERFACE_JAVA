public abstract class Evento {
    protected String nombre;
    protected int duracionHoras;
    
    public Evento(String nombre, int duracionHoras){
        this.nombre=nombre;
        this.duracionHoras=duracionHoras;
        
    }
    public abstract String obtenerCategoria();
}
