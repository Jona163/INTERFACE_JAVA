public class Escuela extends Evento {
    public Escuela(String nombre, int duracionHoras) {
        super(nombre, duracionHoras);
    }

    @Override
    public String obtenerCategoria() {
        return "Escuela";
    }
}

    

