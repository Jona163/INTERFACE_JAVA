import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GestorHorarios1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestor de Horarios");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        frame.setVisible(true);
    }

    private static void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel categoriaLabel = new JLabel("Categoría:");
        categoriaLabel.setBounds(10, 20, 80, 25);
        panel.add(categoriaLabel);

        JComboBox<String> categoriaComboBox = new JComboBox<>(new String[]{"Trabajo", "Escuela", "Familia"});
        categoriaComboBox.setBounds(100, 20, 150, 25);
        panel.add(categoriaComboBox);

        JLabel nombreLabel = new JLabel("Nombre:");
        nombreLabel.setBounds(10, 50, 80, 25);
        panel.add(nombreLabel);

        JTextField nombreText = new JTextField(20);
        nombreText.setBounds(100, 50, 150, 25);
        panel.add(nombreText);

        JLabel duracionLabel = new JLabel("Duración (horas):");
        duracionLabel.setBounds(10, 80, 150, 25);
        panel.add(duracionLabel);

        JTextField duracionText = new JTextField(20);
        duracionText.setBounds(150, 80, 100, 25);
        panel.add(duracionText);

        JButton addButton = new JButton("Agregar Evento");
        addButton.setBounds(10, 110, 150, 25);
        panel.add(addButton);

        addButton.addActionListener(e -> {
            String categoria = (String) categoriaComboBox.getSelectedItem();
            String nombre = nombreText.getText();
            int duracion = Integer.parseInt(duracionText.getText());

            Evento evento = null;
            switch (categoria) {
                case "Trabajo":
                    evento = new Trabajo(nombre, duracion);
                    break;
                case "Escuela":
                    evento = new Escuela(nombre, duracion);
                    break;
                case "Familia":
                    evento = new Familia(nombre, duracion);
                    break;
            }

            if (evento != null) {
                // Aquí puedes agregar el evento a tu gestor de horarios
                System.out.println("Evento agregado: " + evento.obtenerCategoria() + " - " + evento.nombre);
            }
        });
    }

}

